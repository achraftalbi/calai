# CalAI Brand Kit (Replit-ready)

This mini kit gives you a **ready-to-use color system + paywall & UI components** for your CalAI PWA.

## Files
- `tailwind.config.ts` — adds CalAI colors, gradient, shadows, radii
- `src/styles/globals.css` — base Tailwind + `.btn`, `.card` utilities
- `src/components/CTAButton.tsx` — primary/outline button
- `src/components/ProgressBar.tsx` — calorie goal bar with green/amber/red logic
- `src/pages/Paywall.tsx` — complete paywall (annual default, monthly, free)

## How to use
1. Copy **tailwind.config.ts** to your project root (replace or merge).
2. Import `src/styles/globals.css` in your app entry, e.g. `src/main.tsx`.
3. Drop the components/pages into your `src/` tree.
4. Route `/paywall` to `Paywall.tsx` (Wouter). Example:
   ```tsx
   <Route path="/paywall" component={Paywall} />
   ```
5. Wire buttons to your checkout provider (Stripe / Lemon Squeezy / Paddle). Replace the TODOs in `Paywall.tsx`.

Colors: Primary `#06B6D4`, PrimaryDark `#0891B2`, Secondary `#22C55E`, Accent `#F97316`, Warn `#F59E0B`, Error `#EF4444`, Info `#3B82F6`, BG `#F8FAFC`, Ink `#0F172A`.
